/**
 * R.G INFRA CRM — Clients Page
 * Phase 1 Onboarding: Name, Phone, Email, Address, Purchase Date
 * Property: Apartment → Flat (cascade select, availability check)
 * Infrastructure: Parking, Extra Parking
 */

import { Plus, Search, Building2, User } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, type Client, type Apartment, type Flat, type Property } from '../api'
import { usePortalStore } from '../store'
import { usePortalToast } from '../toast'
import { EmptyState, inr, Input, Select, Modal, PortalButton, PortalCard, Textarea } from '../ui'

const emptyForm = {
  name: '', phone: '', email: '', address: '', pan_aadhaar: '', purchase_date: '',
  property_id: '', apartment_id: '', flat_id: '',
  booking_amount: '', booking_percentage: '',
  parking_allotment: false, parking_slot_no: '',
  extra_parking_allotment: false, extra_parking_slot_no: '', extra_parking_charge: '',
}

function parkingCodeFromFlat(flatNumber?: string | number | null, prefix = 'P') {
  const normalized = String(flatNumber ?? '').trim().replace(/[^A-Za-z0-9]/g, '').toUpperCase()
  return normalized ? `${prefix}${normalized}` : ''
}

export function ClientsPage() {
  const store = usePortalStore()
  const toast = usePortalToast()
  const navigate = useNavigate()
  const [search, setSearch] = useState('')
  const [propertyFilter, setPropertyFilter] = useState('')
  const [apartmentFilter, setApartmentFilter] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ ...emptyForm })
  const [saving, setSaving] = useState(false)

  const formatNumber = (value: number) => {
    if (!Number.isFinite(value)) return ''
    return String(Math.round(value * 100) / 100)
  }

  const [properties, setProperties] = useState<Property[]>([])
  const [apartments, setApartments] = useState<Apartment[]>([])
  const [allFlats, setAllFlats] = useState<Flat[]>([])

  useEffect(() => {
    api.getProperties().then(setProperties).catch(() => {})
    api.getApartments().then(setApartments).catch(() => {})
    api.getFlats().then(setAllFlats).catch(() => {})
  }, [])

  const availableApartments = apartments.filter((a) => !form.property_id || a.property_id === Number(form.property_id))
  const availableFlats = allFlats.filter((f) => f.apartment_id === Number(form.apartment_id) && f.is_available && (!f.status || f.status === 'available'))
  const selectedFlat = allFlats.find((f) => f.id === Number(form.flat_id))

  useEffect(() => {
    if (!selectedFlat) return
    const primaryParking = parkingCodeFromFlat(selectedFlat.flat_number)
    const extraParking = parkingCodeFromFlat(selectedFlat.flat_number, 'EP')

    setForm((current) => {
      let next = current
      if (current.parking_allotment && current.parking_slot_no !== primaryParking) {
        next = { ...next, parking_slot_no: primaryParking }
      }
      if (current.extra_parking_allotment && current.extra_parking_slot_no !== extraParking) {
        next = { ...next, extra_parking_slot_no: extraParking }
      }
      return next
    })
  }, [selectedFlat, form.parking_allotment, form.extra_parking_allotment])

  const propertyOptions = Array.from(new Set(store.clients.map((c) => c.property_name).filter(Boolean))) as string[]
  const apartmentOptions = Array.from(new Set(store.clients.map((c) => c.apartment_name).filter(Boolean))) as string[]

  const filteredClients = store.clients.filter((c) => {
    const q = search.toLowerCase()
    if (propertyFilter && c.property_name !== propertyFilter) return false
    if (apartmentFilter && c.apartment_name !== apartmentFilter) return false
    return (
      !q ||
      c.name?.toLowerCase().includes(q) ||
      c.unique_client_id?.toLowerCase().includes(q) ||
      c.phone?.toLowerCase().includes(q) ||
      c.apartment_name?.toLowerCase().includes(q) ||
      c.flat_number?.toLowerCase().includes(q) ||
      c.company_name?.toLowerCase().includes(q) ||
      c.contact_person?.toLowerCase().includes(q)
    )
  })

  const handleAdd = async () => {
    if (!form.name.trim() || !form.flat_id) {
      toast.push({ tone: 'error', title: 'Name and Flat are required' })
      return
    }
    setSaving(true)
    try {
      await api.createClient({
        name: form.name,
        phone: form.phone,
        email: form.email,
        address: form.address,
        pan_aadhaar: form.pan_aadhaar || undefined,
        purchase_date: form.purchase_date || undefined,
        flat_id: Number(form.flat_id),
        booking_amount: form.booking_amount ? Number(form.booking_amount) : undefined,
        booking_percentage: form.booking_percentage ? Number(form.booking_percentage) : undefined,
        parking_allotment: form.parking_allotment,
        parking_slot_no: form.parking_slot_no || undefined,
        extra_parking_allotment: form.extra_parking_allotment,
        extra_parking_slot_no: form.extra_parking_slot_no || undefined,
        extra_parking_charge: form.extra_parking_charge ? Number(form.extra_parking_charge) : undefined,
      } as any)
      toast.push({ tone: 'success', title: 'Client onboarded successfully' })
      setShowAdd(false)
      setForm({ ...emptyForm })
      store.refreshClients()
      store.refreshDashboard()
      api.getFlats().then(setAllFlats).catch(() => {})
    } catch (e) {
      toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed to add client' })
    } finally {
      setSaving(false)
    }
  }

  const displayName = (c: Client) => c.name || c.company_name || '—'

  return (
    <div className="space-y-6">
      <PortalCard>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="text-2xl font-extrabold text-slate-900">Clients</div>
            <div className="text-sm text-slate-500">{store.clients.length} total clients</div>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search clients..."
                className="rounded-xl border border-slate-300 bg-white py-2 pl-10 pr-4 text-sm text-slate-900 outline-none ring-orange-400/40 focus:ring-2 w-56"
              />
            </div>
            <select
              value={propertyFilter}
              onChange={(e) => setPropertyFilter(e.target.value)}
              className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none ring-orange-400/40 focus:ring-2 w-48"
            >
              <option value="">All Properties</option>
              {propertyOptions.map((propertyName) => <option key={propertyName} value={propertyName}>{propertyName}</option>)}
            </select>
            <select
              value={apartmentFilter}
              onChange={(e) => setApartmentFilter(e.target.value)}
              className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none ring-orange-400/40 focus:ring-2 w-48"
            >
              <option value="">All Apartments</option>
              {apartmentOptions.map((apartmentName) => <option key={apartmentName} value={apartmentName}>{apartmentName}</option>)}
            </select>
            <PortalButton onClick={() => setShowAdd(true)}>
              <Plus className="h-4 w-4" /> Add Client
            </PortalButton>
          </div>
        </div>
      </PortalCard>

      {filteredClients.length === 0 ? (
        <EmptyState title="No clients found" sub="Add your first client to get started" />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs font-bold text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="px-5 py-3">Client ID</th>
                  <th className="px-5 py-3">Name</th>
                  <th className="px-5 py-3">Phone</th>
                  <th className="px-5 py-3">Apartment</th>
                  <th className="px-5 py-3">Flat</th>
                  <th className="px-5 py-3 text-right">Total Amount</th>
                  <th className="px-5 py-3 text-right">Paid</th>
                  <th className="px-5 py-3 text-right">Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClients.map((c) => (
                  <tr key={c.id} onClick={() => navigate(`/portal/clients/${c.id}`)} className="cursor-pointer hover:bg-orange-50/50 transition text-slate-700">
                    <td className="px-5 py-4 text-xs font-mono text-orange-600 font-bold">{c.unique_client_id || '—'}</td>
                    <td className="px-5 py-4 font-bold text-slate-900">{displayName(c)}</td>
                    <td className="px-5 py-4">{c.phone || '—'}</td>
                    <td className="px-5 py-4">{c.apartment_name || '—'}</td>
                    <td className="px-5 py-4">{c.flat_number || '—'}</td>
                    <td className="px-5 py-4 text-right font-semibold">{inr(c.total_amount)}</td>
                    <td className="px-5 py-4 text-right text-emerald-600 font-semibold">{inr(c.total_paid)}</td>
                    <td className="px-5 py-4 text-right font-bold" style={{ color: (c.total_due || 0) > 0 ? '#dc2626' : '#059669' }}>{inr(c.total_due)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Onboard New Client" wide closeOnBackdropClick={false}>
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <User className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-bold text-slate-700">Client Details</span>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Input label="Client Name" value={form.name} onChange={(v) => setForm((s) => ({ ...s, name: v }))} required />
            <Input label="Phone" value={form.phone} onChange={(v) => setForm((s) => ({ ...s, phone: v }))} />
            <Input label="Email" value={form.email} onChange={(v) => setForm((s) => ({ ...s, email: v }))} type="email" />
            <Input label="PAN / Aadhaar" value={form.pan_aadhaar} onChange={(v) => setForm((s) => ({ ...s, pan_aadhaar: v }))} />
            <Input label="Purchase Date" value={form.purchase_date} onChange={(v) => setForm((s) => ({ ...s, purchase_date: v }))} type="date" />
          </div>
          <div className="mt-3">
            <Textarea label="Address" value={form.address} onChange={(v) => setForm((s) => ({ ...s, address: v }))} rows={2} />
          </div>
        </div>

        <div className="mb-5 border-t border-slate-100 pt-5">
          <div className="flex items-center gap-2 mb-3">
            <Building2 className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-bold text-slate-700">Property Details</span>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <Select
              label="Property"
              value={form.property_id}
              onChange={(v) => setForm((s) => ({ ...s, property_id: v, apartment_id: '', flat_id: '' }))}
              options={properties.map((p) => ({ value: String(p.id), label: p.name }))}
              placeholder="Select Property..."
            />
            <Select
              label="Apartment"
              value={form.apartment_id}
              onChange={(v) => setForm((s) => ({ ...s, apartment_id: v, flat_id: '' }))}
              options={availableApartments.map((a) => ({ value: String(a.id), label: a.name }))}
              placeholder={!form.property_id ? 'Select property first' : 'Select Apartment...'}
              required
            />
            <Select
              label="Flat Number"
              value={form.flat_id}
              onChange={(v) => {
                const nextFlat = allFlats.find((flat) => String(flat.id) === v)
                const primaryParking = parkingCodeFromFlat(nextFlat?.flat_number)
                const extraParking = parkingCodeFromFlat(nextFlat?.flat_number, 'EP')
                setForm((s) => ({
                  ...s,
                  flat_id: v,
                  parking_slot_no: s.parking_allotment ? primaryParking : '',
                  extra_parking_slot_no: s.extra_parking_allotment ? extraParking : '',
                }))
              }}
              options={availableFlats.map((f) => ({
                value: String(f.id),
                label: `${f.flat_number} — Floor ${f.floor || '—'}, Block ${f.block || '—'} (${f.sbu_area} sqft) — ${inr(f.total_amount)}`,
              }))}
              placeholder={!form.apartment_id ? 'Select apartment first' : availableFlats.length === 0 ? 'No available flats' : 'Select Flat...'}
              required
            />
          </div>

          {form.flat_id && (() => {
            const flatInfo = allFlats.find((flat) => flat.id === Number(form.flat_id))
            if (!flatInfo) return null
            return (
              <div className="mt-3 rounded-xl bg-orange-50 border border-orange-200 p-3">
                <div className="text-xs font-bold text-orange-700 mb-1">Selected Flat Info</div>
                <div className="grid grid-cols-4 gap-2 text-xs text-slate-700">
                  <div><span className="font-semibold">Flat:</span> {flatInfo.flat_number}</div>
                  <div><span className="font-semibold">Floor:</span> {flatInfo.floor || '—'}</div>
                  <div><span className="font-semibold">Block:</span> {flatInfo.block || '—'}</div>
                  <div><span className="font-semibold">SBU Area:</span> {flatInfo.sbu_area} sqft</div>
                </div>
                <div className="mt-1 text-sm font-extrabold text-orange-800">Total Amount: {inr(flatInfo.total_amount)}</div>
              </div>
            )
          })()}

          <div className="mt-3 grid gap-3 max-w-md sm:grid-cols-2">
            <Input
              label="Booking Percentage (%)"
              value={form.booking_percentage}
              onChange={(v) => {
                if (!v) return setForm((s) => ({ ...s, booking_percentage: '', booking_amount: '' }))
                const pct = Number(v)
                const flatInfo = allFlats.find((f) => f.id === Number(form.flat_id))
                if (!flatInfo || Number.isNaN(pct)) return setForm((s) => ({ ...s, booking_percentage: v }))
                const amount = (Number(flatInfo.total_amount || 0) * pct) / 100
                setForm((s) => ({ ...s, booking_percentage: v, booking_amount: formatNumber(amount) }))
              }}
              type="number"
              placeholder="e.g. 10"
            />
            <Input
              label="Booking Amount (₹)"
              value={form.booking_amount}
              onChange={(v) => {
                if (!v) return setForm((s) => ({ ...s, booking_amount: '', booking_percentage: '' }))
                const amt = Number(v)
                const flatInfo = allFlats.find((f) => f.id === Number(form.flat_id))
                if (!flatInfo || Number.isNaN(amt) || Number(flatInfo.total_amount || 0) === 0) {
                  return setForm((s) => ({ ...s, booking_amount: v }))
                }
                const pct = (amt / Number(flatInfo.total_amount || 0)) * 100
                setForm((s) => ({ ...s, booking_amount: v, booking_percentage: formatNumber(pct) }))
              }}
              type="number"
            />
          </div>
        </div>

        <div className="mb-5 border-t border-slate-100 pt-5">
          <div className="flex items-center gap-2 mb-3">
            <Building2 className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-bold text-slate-700">Parking Details</span>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-semibold text-slate-600">Primary Parking Allotment</label>
              <div className="mt-1.5 flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="parking"
                    checked={form.parking_allotment === true}
                    onChange={() => setForm((s) => ({ ...s, parking_allotment: true, parking_slot_no: selectedFlat ? parkingCodeFromFlat(selectedFlat.flat_number) : s.parking_slot_no }))}
                    className="accent-orange-500"
                  />
                  <span className="text-sm text-slate-700">Yes</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="parking"
                    checked={form.parking_allotment === false}
                    onChange={() => setForm((s) => ({ ...s, parking_allotment: false, parking_slot_no: '' }))}
                    className="accent-orange-500"
                  />
                  <span className="text-sm text-slate-700">No</span>
                </label>
              </div>
            </div>
            {form.parking_allotment && (
              <Input label="Primary Parking Slot No" value={form.parking_slot_no} onChange={(v) => setForm((s) => ({ ...s, parking_slot_no: v }))} placeholder="e.g. P101" />
            )}
            <div className="md:col-span-2 rounded-xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-bold text-slate-700">Extra Parking</div>
                  <div className="text-xs text-slate-500">Optional paid parking beyond the primary slot.</div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.extra_parking_allotment === true}
                    onChange={(e) => setForm((s) => ({
                      ...s,
                      extra_parking_allotment: e.target.checked,
                      extra_parking_slot_no: e.target.checked && selectedFlat ? parkingCodeFromFlat(selectedFlat.flat_number, 'EP') : '',
                      extra_parking_charge: e.target.checked ? s.extra_parking_charge : '',
                    }))}
                    className="h-4 w-4 accent-orange-500"
                  />
                  <span className="text-sm font-semibold text-slate-700">Allocate extra parking</span>
                </label>
              </div>
              {form.extra_parking_allotment && (
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                  <Input label="Extra Parking Slot No" value={form.extra_parking_slot_no} onChange={(v) => setForm((s) => ({ ...s, extra_parking_slot_no: v }))} placeholder="e.g. EP101" />
                  <Input label="Extra Parking Charge (₹)" value={form.extra_parking_charge} onChange={(v) => setForm((s) => ({ ...s, extra_parking_charge: v }))} type="number" placeholder="e.g. 250000" />
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
          <PortalButton variant="outline" onClick={() => setShowAdd(false)}>Cancel</PortalButton>
          <PortalButton onClick={handleAdd} disabled={saving || !form.name.trim() || !form.flat_id}>
            {saving ? 'Saving...' : 'Onboard Client'}
          </PortalButton>
        </div>
      </Modal>
    </div>
  )
}