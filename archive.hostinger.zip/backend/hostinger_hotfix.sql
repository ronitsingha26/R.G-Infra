-- R.G INFRA Hostinger hotfix
-- Run this once in phpMyAdmin against u822871577_rg_infra_crm.

DELIMITER $$

DROP PROCEDURE IF EXISTS add_column_if_missing $$
CREATE PROCEDURE add_column_if_missing(
  IN table_name_in VARCHAR(64),
  IN column_name_in VARCHAR(64),
  IN column_definition_in TEXT
)
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = table_name_in
      AND COLUMN_NAME = column_name_in
  ) THEN
    SET @ddl = CONCAT('ALTER TABLE `', table_name_in, '` ADD COLUMN `', column_name_in, '` ', column_definition_in);
    PREPARE stmt FROM @ddl;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END $$

DELIMITER ;

CALL add_column_if_missing('properties', 'land_north', 'VARCHAR(500) NULL AFTER `address`');
CALL add_column_if_missing('properties', 'land_south', 'VARCHAR(500) NULL AFTER `land_north`');
CALL add_column_if_missing('properties', 'land_east', 'VARCHAR(500) NULL AFTER `land_south`');
CALL add_column_if_missing('properties', 'land_west', 'VARCHAR(500) NULL AFTER `land_east`');

CALL add_column_if_missing('apartments', 'property_id', 'INT NULL AFTER `id`');
CALL add_column_if_missing('apartments', 'total_flats', 'INT DEFAULT 0 AFTER `name`');
CALL add_column_if_missing('apartments', 'numbering_pattern', 'VARCHAR(100) NULL AFTER `total_flats`');
CALL add_column_if_missing('apartments', 'parking_slots', 'INT DEFAULT 0 AFTER `numbering_pattern`');
CALL add_column_if_missing('apartments', 'electricity_details', 'VARCHAR(200) NULL AFTER `parking_slots`');
CALL add_column_if_missing('apartments', 'transformer_details', 'VARCHAR(200) NULL AFTER `electricity_details`');
CALL add_column_if_missing('apartments', 'water_connection_details', 'TEXT NULL AFTER `transformer_details`');
CALL add_column_if_missing('apartments', 'floor_north', 'VARCHAR(500) NULL AFTER `water_connection_details`');
CALL add_column_if_missing('apartments', 'floor_south', 'VARCHAR(500) NULL AFTER `floor_north`');
CALL add_column_if_missing('apartments', 'floor_east', 'VARCHAR(500) NULL AFTER `floor_south`');
CALL add_column_if_missing('apartments', 'floor_west', 'VARCHAR(500) NULL AFTER `floor_east`');

CALL add_column_if_missing('infrastructure_details', 'water_connection_details', 'TEXT NULL AFTER `electricity_board_source`');
CALL add_column_if_missing('infrastructure_details', 'extra_parking_allotment', 'BOOLEAN DEFAULT FALSE AFTER `parking_slot_no`');
CALL add_column_if_missing('infrastructure_details', 'extra_parking_slot_no', 'VARCHAR(100) NULL AFTER `extra_parking_allotment`');
CALL add_column_if_missing('infrastructure_details', 'extra_parking_charge', 'DECIMAL(15,2) DEFAULT 0 AFTER `extra_parking_slot_no`');

CALL add_column_if_missing('client_payments', 'booking_id', 'INT NULL AFTER `client_id`');
CALL add_column_if_missing('client_payments', 'payment_percentage', 'DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER `amount`');
CALL add_column_if_missing('client_payments', 'gst_amount', 'DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER `payment_percentage`');
CALL add_column_if_missing('client_payments', 'receipt_no', 'VARCHAR(100) NULL AFTER `reference_no`');
CALL add_column_if_missing('client_payments', 'receipt_file_url', 'VARCHAR(500) NULL AFTER `receipt_no`');
CALL add_column_if_missing('client_payments', 'email_sent', 'BOOLEAN DEFAULT FALSE AFTER `receipt_file_url`');

CALL add_column_if_missing('payment_plans', 'gst_percent', 'DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER `description`');

CALL add_column_if_missing('dues', 'current_due', 'DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER `current_stage_due`');
CALL add_column_if_missing('dues', 'current_due_date', 'DATE NULL AFTER `current_due`');
CALL add_column_if_missing('dues', 'next_installment_amount', 'DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER `next_stage_amount`');
CALL add_column_if_missing('dues', 'next_due_date', 'DATE NULL AFTER `next_installment_amount`');
CALL add_column_if_missing('dues', 'gst_percent', 'DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER `next_due_date`');
CALL add_column_if_missing('dues', 'gst_amount', 'DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER `gst_percent`');
CALL add_column_if_missing('dues', 'total_payable', 'DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER `gst_amount`');

CALL add_column_if_missing('demand_letters', 'gst_percent', 'DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER `due_amount`');

UPDATE dues
SET current_due = COALESCE(NULLIF(current_due, 0), current_stage_due, combined_due, 0),
    next_installment_amount = COALESCE(NULLIF(next_installment_amount, 0), next_stage_amount, 0),
    total_payable = COALESCE(NULLIF(total_payable, 0), current_stage_due, combined_due, 0),
    combined_due = COALESCE(current_stage_due, current_due, 0);

CREATE TABLE IF NOT EXISTS reminder_logs (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  client_id           INT NOT NULL,
  flat_id             INT,
  schedule_id         INT,
  stage_name          VARCHAR(200),
  due_date            DATE,
  combined_due        DECIMAL(15,2) NOT NULL DEFAULT 0,
  current_stage_due   DECIMAL(15,2) NOT NULL DEFAULT 0,
  next_stage_amount   DECIMAL(15,2) NOT NULL DEFAULT 0,
  email_sent          BOOLEAN DEFAULT FALSE,
  email_status        ENUM('sent','failed','skipped') DEFAULT 'skipped',
  whatsapp_initiated  BOOLEAN DEFAULT FALSE,
  demand_letter_id    INT,
  trigger_type        ENUM('cron','manual') DEFAULT 'cron',
  next_due_date       DATE,
  error_message       TEXT,
  sent_on             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  FOREIGN KEY (flat_id) REFERENCES flats(id) ON DELETE SET NULL,
  FOREIGN KEY (schedule_id) REFERENCES payment_schedules(id) ON DELETE SET NULL,
  FOREIGN KEY (demand_letter_id) REFERENCES demand_letters(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS contact_submissions (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(200) NOT NULL,
  phone        VARCHAR(30),
  email        VARCHAR(150),
  project_type VARCHAR(100),
  message      TEXT,
  is_read      BOOLEAN DEFAULT FALSE,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_contact_read_created (is_read, created_at),
  INDEX idx_contact_email (email),
  INDEX idx_contact_phone (phone)
);

INSERT INTO payment_stages (stage_name, percentage, stage_order, apartment_id)
SELECT 'Booking Amount', 10.00, 1, NULL
WHERE NOT EXISTS (SELECT 1 FROM payment_stages WHERE apartment_id IS NULL AND stage_order = 1);

INSERT INTO payment_stages (stage_name, percentage, stage_order, apartment_id)
SELECT 'Agreement Signing', 20.00, 2, NULL
WHERE NOT EXISTS (SELECT 1 FROM payment_stages WHERE apartment_id IS NULL AND stage_order = 2);

INSERT INTO payment_stages (stage_name, percentage, stage_order, apartment_id)
SELECT 'Plinth Level', 15.00, 3, NULL
WHERE NOT EXISTS (SELECT 1 FROM payment_stages WHERE apartment_id IS NULL AND stage_order = 3);

INSERT INTO payment_stages (stage_name, percentage, stage_order, apartment_id)
SELECT 'First Slab', 15.00, 4, NULL
WHERE NOT EXISTS (SELECT 1 FROM payment_stages WHERE apartment_id IS NULL AND stage_order = 4);

INSERT INTO payment_stages (stage_name, percentage, stage_order, apartment_id)
SELECT 'Brickwork & Plaster', 20.00, 5, NULL
WHERE NOT EXISTS (SELECT 1 FROM payment_stages WHERE apartment_id IS NULL AND stage_order = 5);

INSERT INTO payment_stages (stage_name, percentage, stage_order, apartment_id)
SELECT 'Possession', 20.00, 6, NULL
WHERE NOT EXISTS (SELECT 1 FROM payment_stages WHERE apartment_id IS NULL AND stage_order = 6);

DROP PROCEDURE IF EXISTS add_column_if_missing;
