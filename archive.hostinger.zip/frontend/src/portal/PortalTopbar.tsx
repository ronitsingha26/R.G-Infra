import { CalendarDays, LogOut, Menu, ShieldCheck } from 'lucide-react'
import { usePortalAuth } from './auth'

export function PortalTopbar({ onToggleSidebar }: { onToggleSidebar: () => void }) {
  const { user, logout } = usePortalAuth()

  return (
    <header className="sticky top-0 z-30 flex h-20 items-center justify-between border-b border-slate-200/70 bg-white/85 px-4 shadow-[0_10px_34px_rgba(15,23,42,0.04)] backdrop-blur-xl sm:px-6 lg:px-8">
      <div className="flex items-center gap-4">
        <button onClick={onToggleSidebar} className="rounded-lg border border-slate-200 bg-white p-2 text-slate-600 shadow-sm transition hover:border-orange-200 hover:text-slate-900 lg:hidden">
          <Menu className="h-5 w-5" />
        </button>
        <div className="hidden items-center gap-3 rounded-lg border border-slate-200 bg-white px-4 py-2.5 shadow-sm sm:flex">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
            <CalendarDays className="h-[18px] w-[18px]" />
          </div>
          <div>
            <div className="text-[10px] font-black uppercase tracking-[0.16em] text-slate-400">Today</div>
            <div className="text-sm font-bold text-slate-700">
              {new Intl.DateTimeFormat('en-IN', { weekday: 'long', day: '2-digit', month: 'short', year: 'numeric' }).format(new Date())}
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden items-center gap-3 rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-sm sm:flex">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 text-xs font-black text-white shadow-[0_8px_18px_rgba(249,115,22,0.22)]">
            {(user?.name || 'Admin').slice(0, 1).toUpperCase()}
          </div>
          <div className="text-right">
            <div className="text-sm font-extrabold tracking-[-0.02em] text-slate-950">{user?.name || 'Admin'}</div>
            <div className="flex items-center justify-end gap-1 text-[11px] font-bold uppercase tracking-[0.08em] text-slate-400">
              <ShieldCheck className="h-3 w-3 text-emerald-500" />
              {user?.role || 'admin'}
            </div>
          </div>
        </div>
        <button
          onClick={logout}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs font-bold text-slate-600 shadow-sm transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
        >
          <LogOut className="h-4 w-4" />
          Logout
        </button>
      </div>
    </header>
  )
}
