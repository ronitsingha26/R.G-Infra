/**
 * R.G INFRA CRM — Projects / Property Management Page
 * Manages: Properties → Apartments → Flats → Infrastructure → Client Allocation
 * Full CRUD for properties, apartments & flats, inline infrastructure editing
 */

import {
  Building2, ChevronDown, ChevronRight, Edit, Home,
  Plus, Search, Trash2, Users, Briefcase
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { api, type Apartment, type Flat, type Property } from '../api'
import { usePortalStore } from '../store'
import { usePortalToast } from '../toast'
import { EmptyState, Input, Modal, PortalButton, PortalCard } from '../ui'

export function ProjectsPage() {
  const store = usePortalStore()
  const toast = usePortalToast()
  const [search, setSearch] = useState('')

  // Data
  const [properties, setProperties] = useState<Property[]>([])
  const [apartments, setApartments] = useState<Apartment[]>([])
  const [allFlats, setAllFlats] = useState<Flat[]>([])
  const [loading, setLoading] = useState(true)

  // Expanded state for accordion
  const [expandedProp, setExpandedProp] = useState<number | null>(null)
  const [expandedApt, setExpandedApt] = useState<number | null>(null)

  // Modals
  const [propModal, setPropModal] = useState<{ open: boolean; editing?: Property }>({ open: false })
  const [aptModal, setAptModal] = useState<{ open: boolean; propId: number; editing?: Apartment }>({ open: false, propId: 0 })
  const [flatModal, setFlatModal] = useState<{ open: boolean; aptId: number; editing?: Flat }>({ open: false, aptId: 0 })

  const emptyPropForm = { name: '', address: '', land_north: '', land_south: '', land_east: '', land_west: '' }
  const emptyAptForm = {
    name: '', total_flats: '', numbering_pattern: '', parking_slots: '', electricity_details: '', transformer_details: '', water_connection_details: '',
    floor_north: '', floor_south: '', floor_east: '', floor_west: ''
  }
  const [propForm, setPropForm] = useState(emptyPropForm)
  const [aptForm, setAptForm] = useState({
    ...emptyAptForm
  })
  const [flatForm, setFlatForm] = useState({ flat_number: '', floor: '', block: '', sbu_area: '', total_amount: '' })
  const [saving, setSaving] = useState(false)

  const loadData = async () => {
    try {
      setLoading(true)
      const [props, apts, flats] = await Promise.all([
        api.getProperties().catch(() => [] as Property[]),
        api.getApartments(),
        api.getFlats()
      ])
      setProperties(props)
      setApartments(apts)
      setAllFlats(flats)
    } catch {
      toast.push({ tone: 'error', title: 'Failed to load data' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadData() }, [])

  // Helpers
  const getAptsForProp = (propId: number) => apartments.filter(a => a.property_id === propId)
  const getFlatsForApt = (aptId: number) => allFlats.filter(f => f.apartment_id === aptId)
  const getClientForFlat = (flatId: number) => store.clients.find(c => c.flat_id === flatId)

  // Stats
  const totalFlats = allFlats.length
  const bookedFlats = allFlats.filter(f => !f.is_available).length
  const availableFlats = totalFlats - bookedFlats

  // ─── Property CRUD ─────────────────────────────────────
  const openAddProp = () => { setPropForm(emptyPropForm); setPropModal({ open: true }) }
  const openEditProp = (prop: Property) => {
    setPropForm({
      name: prop.name,
      address: prop.address || '',
      land_north: prop.land_north || '',
      land_south: prop.land_south || '',
      land_east: prop.land_east || '',
      land_west: prop.land_west || '',
    })
    setPropModal({ open: true, editing: prop })
  }

  const handleSaveProp = async () => {
    if (!propForm.name.trim()) return
    setSaving(true)
    try {
      if (propModal.editing) {
        await api.updateProperty(propModal.editing.id, propForm)
        toast.push({ tone: 'success', title: 'Property updated' })
      } else {
        await api.createProperty(propForm)
        toast.push({ tone: 'success', title: 'Property added' })
      }
      setPropModal({ open: false })
      loadData()
    } catch (e) { toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed' }) }
    finally { setSaving(false) }
  }

  const handleDeleteProp = async (prop: Property) => {
    if (!confirm(`Delete "${prop.name}"? All apartments and flats inside will also be deleted.`)) return
    try {
      await api.deleteProperty(prop.id)
      toast.push({ tone: 'success', title: 'Property deleted' })
      loadData()
    } catch (e) { toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed' }) }
  }

  // ─── Apartment CRUD ─────────────────────────────────────
  const openAddApt = (propId: number) => {
    setAptForm(emptyAptForm)
    setAptModal({ open: true, propId })
  }
  const openEditApt = (apt: Apartment) => {
    setAptForm({
      name: apt.name,
      total_flats: String(apt.total_flats || ''),
      numbering_pattern: apt.numbering_pattern || '',
      parking_slots: String(apt.parking_slots || ''),
      electricity_details: apt.electricity_details || '',
      transformer_details: apt.transformer_details || '',
      water_connection_details: apt.water_connection_details || '',
      floor_north: apt.floor_north || '',
      floor_south: apt.floor_south || '',
      floor_east: apt.floor_east || '',
      floor_west: apt.floor_west || '',
    })
    setAptModal({ open: true, propId: apt.property_id || 0, editing: apt })
  }

  const handleSaveApt = async () => {
    if (!aptForm.name.trim()) return
    setSaving(true)
    try {
      const payload = {
        name: aptForm.name,
        property_id: aptModal.propId || undefined,
        total_flats: aptForm.total_flats ? Number(aptForm.total_flats) : undefined,
        numbering_pattern: aptForm.numbering_pattern || undefined,
        parking_slots: aptForm.parking_slots ? Number(aptForm.parking_slots) : undefined,
        electricity_details: aptForm.electricity_details || undefined,
        transformer_details: aptForm.transformer_details || undefined,
        water_connection_details: aptForm.water_connection_details || undefined,
        floor_north: aptForm.floor_north || undefined,
        floor_south: aptForm.floor_south || undefined,
        floor_east: aptForm.floor_east || undefined,
        floor_west: aptForm.floor_west || undefined,
      }

      if (aptModal.editing) {
        await api.updateApartment(aptModal.editing.id, payload)
        toast.push({ tone: 'success', title: 'Apartment updated' })
      } else {
        await api.createApartment(payload)
        toast.push({ tone: 'success', title: 'Apartment & Flats auto-generated' })
      }
      setAptModal({ open: false, propId: 0 })
      loadData()
    } catch (e) { toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed' }) }
    finally { setSaving(false) }
  }

  const handleDeleteApt = async (apt: Apartment) => {
    if (!confirm(`Delete "${apt.name}"? All flats inside will also be deleted.`)) return
    try {
      await api.deleteApartment(apt.id)
      toast.push({ tone: 'success', title: 'Apartment deleted' })
      loadData()
    } catch (e) { toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed' }) }
  }

  // ─── Flat CRUD ──────────────────────────────────────────
  const openAddFlat = (aptId: number) => {
    setFlatForm({ flat_number: '', floor: '', block: '', sbu_area: '', total_amount: '' })
    setFlatModal({ open: true, aptId })
  }
  const openEditFlat = (flat: Flat) => {
    setFlatForm({
      flat_number: flat.flat_number,
      floor: flat.floor || '',
      block: flat.block || '',
      sbu_area: String(flat.sbu_area || ''),
      total_amount: String(flat.total_amount || ''),
    })
    setFlatModal({ open: true, aptId: flat.apartment_id, editing: flat })
  }

  const handleSaveFlat = async () => {
    if (!flatForm.flat_number.trim()) return
    setSaving(true)
    try {
      const data: Partial<Flat> = {
        apartment_id: flatModal.aptId,
        flat_number: flatForm.flat_number,
        floor: flatForm.floor || undefined,
        block: flatForm.block || undefined,
        sbu_area: flatForm.sbu_area ? Number(flatForm.sbu_area) : undefined,
        total_amount: flatForm.total_amount ? Number(flatForm.total_amount) : undefined,
        is_available: flatModal.editing ? flatModal.editing.is_available : true,
      } as any
      if (flatModal.editing) {
        await api.updateFlat(flatModal.editing.id, data)
        toast.push({ tone: 'success', title: 'Flat updated' })
      } else {
        await api.createFlat(data)
        toast.push({ tone: 'success', title: 'Flat added' })
      }
      setFlatModal({ open: false, aptId: 0 })
      loadData()
    } catch (e) { toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed' }) }
    finally { setSaving(false) }
  }

  const handleDeleteFlat = async (flat: Flat) => {
    if (!confirm(`Delete Flat ${flat.flat_number}?`)) return
    try {
      await api.deleteFlat(flat.id)
      toast.push({ tone: 'success', title: 'Flat deleted' })
      loadData()
      store.refreshClients()
    } catch (e) { toast.push({ tone: 'error', title: e instanceof Error ? e.message : 'Failed' }) }
  }

  if (loading) return <div className="flex items-center justify-center py-24"><div className="h-8 w-8 animate-spin rounded-full border-4 border-orange-400 border-t-transparent" /></div>

  return (
    <div className="space-y-6">
      {/* Header */}
      <PortalCard>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="text-2xl font-extrabold text-slate-900">Projects & Properties</div>
            <div className="text-sm text-slate-500">Manage properties, apartments, flats & infrastructure</div>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="rounded-xl border border-slate-300 bg-white py-2 pl-10 pr-4 text-sm outline-none ring-orange-400/40 focus:ring-2 w-48" />
            </div>
            <PortalButton onClick={openAddProp}><Plus className="h-4 w-4" /> Add Property</PortalButton>
          </div>
        </div>
      </PortalCard>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-4">
        <PortalCard>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-orange-50 flex items-center justify-center"><Briefcase className="h-5 w-5 text-orange-500" /></div>
            <div><div className="text-xs text-slate-400 font-semibold">Properties</div><div className="text-xl font-extrabold text-slate-900">{properties.length}</div></div>
          </div>
        </PortalCard>
        <PortalCard>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center"><Building2 className="h-5 w-5 text-blue-500" /></div>
            <div><div className="text-xs text-slate-400 font-semibold">Apartments</div><div className="text-xl font-extrabold text-slate-900">{apartments.length}</div></div>
          </div>
        </PortalCard>
        <PortalCard>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 flex items-center justify-center"><Users className="h-5 w-5 text-emerald-500" /></div>
            <div><div className="text-xs text-slate-400 font-semibold">Booked Flats</div><div className="text-xl font-extrabold text-emerald-600">{bookedFlats}</div></div>
          </div>
        </PortalCard>
        <PortalCard>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-amber-50 flex items-center justify-center"><Home className="h-5 w-5 text-amber-500" /></div>
            <div><div className="text-xs text-slate-400 font-semibold">Available Flats</div><div className="text-xl font-extrabold text-amber-600">{availableFlats}</div></div>
          </div>
        </PortalCard>
      </div>

      {/* ─── PROPERTIES LIST ─── */}
      {properties.length === 0 ? <EmptyState title="No properties found" sub="Add your first property to get started" /> : (
        <div className="space-y-4">
          {properties.filter(p => p.name.toLowerCase().includes(search.toLowerCase())).map(prop => {
            const apts = getAptsForProp(prop.id)
            const isPropExpanded = expandedProp === prop.id

            return (
              <PortalCard key={prop.id} className="!p-0 overflow-hidden border border-slate-200">
                {/* Property Header */}
                <div
                  className="flex items-center gap-3 p-5 cursor-pointer hover:bg-slate-50 transition"
                  onClick={() => setExpandedProp(isPropExpanded ? null : prop.id)}
                >
                  <div className="h-10 w-10 rounded-xl bg-blue-100 flex items-center justify-center shrink-0">
                    <Briefcase className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-lg font-extrabold text-slate-900">{prop.name}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {apts.length} Apartments • {prop.address || 'No address provided'}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button onClick={(e) => { e.stopPropagation(); openEditProp(prop) }} className="p-1.5 rounded-lg hover:bg-orange-50 text-slate-400 hover:text-orange-500 transition">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleDeleteProp(prop) }} className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition">
                      <Trash2 className="h-4 w-4" />
                    </button>
                    {isPropExpanded ? <ChevronDown className="h-5 w-5 text-slate-400" /> : <ChevronRight className="h-5 w-5 text-slate-400" />}
                  </div>
                </div>

                {/* Expanded Property -> Apartments Section */}
                {isPropExpanded && (
                  <div className="border-t border-slate-100 bg-slate-50/50 p-4 space-y-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-bold text-slate-700">Apartments in {prop.name}</span>
                      <PortalButton onClick={() => openAddApt(prop.id)} className="!py-1.5 !px-3 !text-xs">
                        <Plus className="h-3.5 w-3.5" /> Add Apartment
                      </PortalButton>
                    </div>

                    {apts.length === 0 ? <div className="text-sm text-slate-400 text-center py-4">No apartments added yet</div> : (
                      apts.map(apt => {
                        const flats = getFlatsForApt(apt.id)
                        const isAptExpanded = expandedApt === apt.id

                        return (
                          <div key={apt.id} className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
                            <div className="flex items-center gap-3 p-4 cursor-pointer hover:bg-slate-50 transition" onClick={() => setExpandedApt(isAptExpanded ? null : apt.id)}>
                              <Building2 className="h-5 w-5 text-orange-500" />
                              <div className="flex-1">
                                <div className="text-sm font-bold text-slate-900">{apt.name}</div>
                                <div className="text-xs text-slate-500">
                                  {flats.length} flats • {apt.parking_slots || 0} parking slots
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <button onClick={(e) => { e.stopPropagation(); openEditApt(apt) }} className="p-1.5 rounded-lg hover:bg-orange-50 text-slate-400 hover:text-orange-500 transition">
                                  <Edit className="h-4 w-4" />
                                </button>
                                <button onClick={(e) => { e.stopPropagation(); handleDeleteApt(apt) }} className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition">
                                  <Trash2 className="h-4 w-4" />
                                </button>
                                {isAptExpanded ? <ChevronDown className="h-4 w-4 text-slate-400" /> : <ChevronRight className="h-4 w-4 text-slate-400" />}
                              </div>
                            </div>

                            {/* Expanded Apartment -> Flats */}
                            {isAptExpanded && (
                              <div className="border-t border-slate-100 bg-slate-50/50">
                                <div className="px-4 py-2 flex justify-between items-center border-b border-slate-100">
                                  <span className="text-xs font-bold text-slate-600">Flats</span>
                                  <PortalButton onClick={() => openAddFlat(apt.id)} variant="outline" className="!py-1 !px-2 !text-[10px]">
                                    <Plus className="h-3 w-3" /> Add Flat
                                  </PortalButton>
                                </div>
                                <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
                                  {flats.map(flat => {
                                    const client = getClientForFlat(flat.id)
                                    return (
                                      <div key={flat.id} className="p-4 hover:bg-white transition flex items-center justify-between">
                                        <div>
                                          <div className="flex items-center gap-2">
                                            <span className="text-sm font-bold text-slate-900">Flat {flat.flat_number}</span>
                                            <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${flat.is_available ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                              {flat.is_available ? 'Available' : 'Booked'}
                                            </span>
                                          </div>
                                          {client && <div className="text-xs text-slate-500 mt-1">Booked by {client.name}</div>}
                                        </div>
                                        <div className="flex gap-1">
                                          <button onClick={() => openEditFlat(flat)} className="p-1 text-slate-400 hover:text-orange-500"><Edit className="h-3.5 w-3.5" /></button>
                                          <button onClick={() => handleDeleteFlat(flat)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></button>
                                        </div>
                                      </div>
                                    )
                                  })}
                                </div>
                              </div>
                            )}
                          </div>
                        )
                      })
                    )}
                  </div>
                )}
              </PortalCard>
            )
          })}
        </div>
      )}

      {/* ─── Add/Edit Property Modal ─── */}
      <Modal open={propModal.open} onClose={() => setPropModal({ open: false })} title={propModal.editing ? 'Edit Property' : 'Add New Property'} closeOnBackdropClick={false}>
        <div className="space-y-4">
          <Input label="Property Name" value={propForm.name} onChange={(v) => setPropForm(s => ({...s, name: v}))} required placeholder="e.g. RG Residency" />
          <Input label="Address" value={propForm.address} onChange={(v) => setPropForm(s => ({...s, address: v}))} placeholder="Property Location" />
          <div>
            <div className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Land Boundaries</div>
            <div className="grid gap-3 md:grid-cols-2">
              <Input label="North" value={propForm.land_north} onChange={(v) => setPropForm(s => ({...s, land_north: v}))} placeholder="North side detail" />
              <Input label="South" value={propForm.land_south} onChange={(v) => setPropForm(s => ({...s, land_south: v}))} placeholder="South side detail" />
              <Input label="East" value={propForm.land_east} onChange={(v) => setPropForm(s => ({...s, land_east: v}))} placeholder="East side detail" />
              <Input label="West" value={propForm.land_west} onChange={(v) => setPropForm(s => ({...s, land_west: v}))} placeholder="West side detail" />
            </div>
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <PortalButton variant="outline" onClick={() => setPropModal({ open: false })}>Cancel</PortalButton>
          <PortalButton onClick={handleSaveProp} disabled={saving || !propForm.name.trim()}>
            {saving ? 'Saving...' : propModal.editing ? 'Update' : 'Add Property'}
          </PortalButton>
        </div>
      </Modal>

      {/* ─── Add/Edit Apartment Modal ─── */}
      <Modal open={aptModal.open} onClose={() => setAptModal({ open: false, propId: 0 })} title={aptModal.editing ? 'Edit Apartment' : 'Add New Apartment'} wide closeOnBackdropClick={false}>
        <div className="grid gap-4 md:grid-cols-2">
          <Input label="Apartment Name" value={aptForm.name} onChange={(v) => setAptForm(s => ({...s, name: v}))} required placeholder="e.g. Tower A" />
          <Input label="Total Flats" value={aptForm.total_flats} onChange={(v) => setAptForm(s => ({...s, total_flats: v, parking_slots: s.parking_slots || (v ? String(Number(v) * 2) : '') }))} type="number" placeholder="e.g. 50" />
          <Input label="Numbering Pattern" value={aptForm.numbering_pattern} onChange={(v) => setAptForm(s => ({...s, numbering_pattern: v}))} placeholder="e.g. 101" />
          <Input label="Total Parking Slots" value={aptForm.parking_slots} onChange={(v) => setAptForm(s => ({...s, parking_slots: v}))} type="number" placeholder="e.g. 60" />
          <Input label="Electricity Details" value={aptForm.electricity_details} onChange={(v) => setAptForm(s => ({...s, electricity_details: v}))} placeholder="e.g. WBSEDCL" />
          <Input label="Transformer Details" value={aptForm.transformer_details} onChange={(v) => setAptForm(s => ({...s, transformer_details: v}))} placeholder="e.g. 500kVA" />
          <div className="md:col-span-2">
            <Input label="Water Connection Details" value={aptForm.water_connection_details} onChange={(v) => setAptForm(s => ({...s, water_connection_details: v}))} placeholder="e.g. Municipal + borewell supply" />
          </div>
          <div className="md:col-span-2">
            <div className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Floor Boundaries for Demand Letter</div>
            <div className="grid gap-4 md:grid-cols-2">
              <Input label="North" value={aptForm.floor_north} onChange={(v) => setAptForm(s => ({...s, floor_north: v}))} placeholder="e.g. Flat No. 903" />
              <Input label="South" value={aptForm.floor_south} onChange={(v) => setAptForm(s => ({...s, floor_south: v}))} placeholder="e.g. Side Setback" />
              <Input label="East" value={aptForm.floor_east} onChange={(v) => setAptForm(s => ({...s, floor_east: v}))} placeholder="e.g. Rear Setback" />
              <Input label="West" value={aptForm.floor_west} onChange={(v) => setAptForm(s => ({...s, floor_west: v}))} placeholder="e.g. Pool and Garden area" />
            </div>
          </div>
        </div>
        {!aptModal.editing && (
          <div className="mt-4 text-xs text-amber-700 bg-amber-50 p-3 rounded-lg">
            <strong>Note:</strong> We will automatically generate {aptForm.total_flats || '0'} flats starting from {aptForm.numbering_pattern || '1'}. You can edit individual flat details later.
          </div>
        )}
        <div className="mt-3 text-xs text-slate-500">
          Parking slots default to roughly 2 per flat so you can keep one primary slot per flat and still have extra paid parking available.
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <PortalButton variant="outline" onClick={() => setAptModal({ open: false, propId: 0 })}>Cancel</PortalButton>
          <PortalButton onClick={handleSaveApt} disabled={saving || !aptForm.name.trim()}>
            {saving ? 'Saving...' : aptModal.editing ? 'Update' : 'Add Apartment'}
          </PortalButton>
        </div>
      </Modal>

      {/* ─── Add/Edit Flat Modal ─── */}
      <Modal open={flatModal.open} onClose={() => setFlatModal({ open: false, aptId: 0 })} title={flatModal.editing ? 'Edit Flat' : 'Add New Flat'} wide closeOnBackdropClick={false}>
        <div className="grid gap-4 md:grid-cols-2">
          <Input label="Flat Number" value={flatForm.flat_number} onChange={(v) => setFlatForm(s => ({ ...s, flat_number: v }))} required placeholder="e.g. 101A" />
          <Input label="Floor" value={flatForm.floor} onChange={(v) => setFlatForm(s => ({ ...s, floor: v }))} placeholder="e.g. 1st" />
          <Input label="Block" value={flatForm.block} onChange={(v) => setFlatForm(s => ({ ...s, block: v }))} placeholder="e.g. A" />
          <Input label="SBU Area (sqft)" value={flatForm.sbu_area} onChange={(v) => setFlatForm(s => ({ ...s, sbu_area: v }))} type="number" placeholder="e.g. 1250" />
          <Input label="Total Amount (₹)" value={flatForm.total_amount} onChange={(v) => setFlatForm(s => ({ ...s, total_amount: v }))} type="number" placeholder="e.g. 7500000" />
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <PortalButton variant="outline" onClick={() => setFlatModal({ open: false, aptId: 0 })}>Cancel</PortalButton>
          <PortalButton onClick={handleSaveFlat} disabled={saving || !flatForm.flat_number.trim()}>
            {saving ? 'Saving...' : flatModal.editing ? 'Update Flat' : 'Add Flat'}
          </PortalButton>
        </div>
      </Modal>
    </div>
  )
}
