import { Router } from 'express';
import pool from '../config/db.js';
import { verifyToken } from '../middleware/auth.js';

const router = Router();

// GET /api/flats
router.get('/', verifyToken, async (req, res) => {
  try {
    const [flats] = await pool.query(`
      SELECT f.*, a.name as apartment_name 
      FROM flats f
      LEFT JOIN apartments a ON f.apartment_id = a.id
      ORDER BY f.created_at DESC
    `);
    res.json(flats);
  } catch (err) {
    console.error('Get flats error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/flats
router.post('/', verifyToken, async (req, res) => {
  try {
    const { apartment_id, tower_id, flat_number, floor, block, sbu_area, total_amount, is_available, status } = req.body;
    if (!apartment_id || !flat_number) return res.status(400).json({ error: 'apartment_id and flat_number are required' });

    const nextStatus = status || (is_available === false ? 'booked' : 'available');
    const [result] = await pool.query(
      'INSERT INTO flats (apartment_id, tower_id, flat_number, floor, block, sbu_area, total_amount, is_available, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [apartment_id, tower_id || null, flat_number, floor || null, block || null, sbu_area || null, total_amount || null, is_available !== undefined ? is_available : nextStatus === 'available', nextStatus]
    );
    const [rows] = await pool.query('SELECT * FROM flats WHERE id = ?', [result.insertId]);
    req.app.get('io')?.emit('data_changed', { type: 'project_added' });
    res.status(201).json(rows[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(400).json({ error: 'Flat number already exists in this apartment' });
    console.error('Create flat error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/flats/:id
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const { apartment_id, tower_id, flat_number, floor, block, sbu_area, total_amount, is_available, status } = req.body;
    const nextStatus = status || (is_available === false ? 'booked' : 'available');
    
    await pool.query(
      'UPDATE flats SET apartment_id = ?, tower_id = ?, flat_number = ?, floor = ?, block = ?, sbu_area = ?, total_amount = ?, is_available = ?, status = ? WHERE id = ?',
      [apartment_id, tower_id || null, flat_number, floor, block, sbu_area, total_amount, is_available, nextStatus, req.params.id]
    );

    const [rows] = await pool.query('SELECT * FROM flats WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Flat not found' });
    req.app.get('io')?.emit('data_changed', { type: 'project_updated' });
    res.json(rows[0]);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(400).json({ error: 'Flat number already exists in this apartment' });
    console.error('Update flat error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/flats/:id
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    await pool.query('DELETE FROM flats WHERE id = ?', [req.params.id]);
    req.app.get('io')?.emit('data_changed', { type: 'project_deleted' });
    res.json({ message: 'Flat deleted' });
  } catch (err) {
    console.error('Delete flat error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
